import json
import requests
import time

def lambda_handler(event, context):
    """Validate Ray code by executing on remote Ray cluster"""
    
    print(f"Lambda invoked with event: {json.dumps(event)}")
    
    try:
        # Handle both direct invocation and MCP Gateway formats
        if 'arguments' in event:
            # MCP Gateway format
            args = event['arguments']
            code = args.get('code', '')
            ray_cluster_ip = args.get('ray_cluster_ip', '172.31.4.12')
        else:
            # Direct invocation format
            code = event.get('code', '')
            ray_cluster_ip = event.get('ray_cluster_ip', '172.31.4.12')
        
        print(f"Code length: {len(code)}")
        print(f"Ray cluster IP: {ray_cluster_ip}")
        
        if not code:
            print("No code provided")
            return {
                'success': False,
                'error': 'No code provided'
            }
        
        # Ray cluster endpoints
        ray_dashboard_url = f"http://{ray_cluster_ip}:8265"
        ray_jobs_api = f"{ray_dashboard_url}/api/jobs/"
        
        print(f"Testing connectivity to {ray_dashboard_url}")
        
        # Test connectivity
        try:
            response = requests.get(f"{ray_dashboard_url}/api/cluster_status", timeout=10)
            print(f"Cluster status response: {response.status_code}")
            if response.status_code != 200:
                return {
                    'success': False,
                    'error': f'Cannot connect to Ray cluster at {ray_cluster_ip}:8265'
                }
        except Exception as e:
            print(f"Connectivity error: {e}")
            return {
                'success': False,
                'error': f'Cannot connect to Ray cluster at {ray_cluster_ip}:8265. Network connectivity issue.'
            }
        
        # Submit Ray job
        job_spec = {
            "entrypoint": f"python -c \"{code.replace(chr(34), chr(92)+chr(34))}\"",
            "runtime_env": {},
            "job_id": None,
            "metadata": {"job_submission_id": f"validation_{int(time.time())}"}
        }
        
        print(f"Submitting job to {ray_jobs_api}")
        
        # Submit job
        submit_response = requests.post(ray_jobs_api, json=job_spec, timeout=30)
        
        print(f"Job submission response: {submit_response.status_code}")
        
        if submit_response.status_code != 200:
            print(f"Job submission failed: {submit_response.text}")
            return {
                'success': False,
                'error': f'Job submission failed: {submit_response.text}'
            }
        
        job_id = submit_response.json().get('job_id')
        print(f"Job submitted with ID: {job_id}")
        
        # Wait for completion (up to 30 seconds)
        for i in range(30):
            status_response = requests.get(f"{ray_jobs_api}{job_id}", timeout=10)
            if status_response.status_code == 200:
                job_status = status_response.json()
                status = job_status.get('status')
                
                print(f"Job status check {i+1}: {status}")
                
                if status == 'SUCCEEDED':
                    print("Job succeeded! Getting job logs...")
                    
                    # Get job logs to capture actual output
                    try:
                        logs_response = requests.get(f"{ray_jobs_api}{job_id}/logs", timeout=10)
                        output = ""
                        if logs_response.status_code == 200:
                            logs_data = logs_response.json()
                            # Extract stdout from logs
                            if isinstance(logs_data, dict) and 'logs' in logs_data:
                                for log_entry in logs_data['logs']:
                                    if isinstance(log_entry, dict):
                                        if log_entry.get('level') == 'INFO' or 'stdout' in log_entry:
                                            output += log_entry.get('message', '') + "\n"
                            elif isinstance(logs_data, dict):
                                output = logs_data.get('stdout', str(logs_data))
                            else:
                                output = str(logs_data)
                        
                        if not output.strip():
                            output = f"Job completed successfully (Job ID: {job_id})"
                            
                    except Exception as log_error:
                        print(f"Failed to get logs: {log_error}")
                        output = f"Job completed successfully (Job ID: {job_id})"
                    
                    return {
                        'success': True,
                        'job_id': job_id,
                        'status': status,
                        'output': output.strip()
                    }
                elif status in ['FAILED', 'STOPPED']:
                    print(f"Job failed with status: {status}")
                    return {
                        'success': False,
                        'error': f'Job {status.lower()}: {job_status.get("message", "Unknown error")}',
                        'job_id': job_id
                    }
            
            time.sleep(1)
        
        print("Job validation timeout")
        return {
            'success': False,
            'error': 'Job validation timeout',
            'job_id': job_id
        }
        
    except Exception as e:
        print(f"Exception in lambda_handler: {e}")
        return {
            'success': False,
            'error': f'Validation error: {str(e)}'
        }
